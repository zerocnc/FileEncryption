import java.awt.*;
import java.io.*;

public class FinalGroup {

	public static void main(String[] args) throws IOException, Exception {
		
		Frame guiFrame = new Frame("User Interface");
		Button xor = new Button("XOR");
		Button xordec = new Button("Decrypt XOR");
		Button negation = new Button("Negation");
		Button negdec = new Button("Decrypt Negation");
		Button aes = new Button("AES");
		Button aesdec = new Button("Decrypt AES");
		Button rsa = new Button("RSA");
		Button rsadec = new Button("Decrypt RSA");
		Button exit = new Button("Exit");
		
		xor.setActionCommand("XOR");
		xordec.setActionCommand("XORdec");
		negation.setActionCommand("Negation");
		negdec.setActionCommand("NEGdec");
		aes.setActionCommand("AES");
		aesdec.setActionCommand("AESdec");
		rsa.setActionCommand("RSA");
		rsadec.setActionCommand("RSAdec");
		exit.setActionCommand("Exit");
		
		xor.addActionListener(new ButtonClickListener());
		xordec.addActionListener(new ButtonClickListener());
		negation.addActionListener(new ButtonClickListener());
		negdec.addActionListener(new ButtonClickListener());
		aes.addActionListener(new ButtonClickListener());
		aesdec.addActionListener(new ButtonClickListener());
		rsa.addActionListener(new ButtonClickListener());
		rsadec.addActionListener(new ButtonClickListener());
		exit.addActionListener(new ButtonClickListener());
		
		guiFrame.add(xor);
		guiFrame.add(xordec);
		guiFrame.add(negation);
		guiFrame.add(negdec);
		guiFrame.add(aes);
		guiFrame.add(aesdec);
		guiFrame.add(rsa);
		guiFrame.add(rsadec);
		guiFrame.add(exit);
		guiFrame.add(ButtonClickListener.output);
		ButtonClickListener.output.setText("Welcome. All output is written to C:/CS4800");
		
		guiFrame.setSize(750,750);
		guiFrame.setLayout(new GridLayout(0,2));
		guiFrame.setVisible(true);
		guiFrame.requestFocus();
		
	}
}
