import java.awt.FileDialog;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.JFrame;

public class ButtonClickListener implements ActionListener {
	static FileDialog fd = new FileDialog(new JFrame(), "Please choose the file to encrypt");
	static TextArea output = new TextArea();
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		new File("C:/CS4800").mkdir();
		if(command.equals("XOR")) {
			try {
				xor();
			} catch (IOException | NoSuchAlgorithmException e1) {
				e1.printStackTrace();
			}
		}
		else if(command.equals("XORdec")) {
			try {
				xordec();
				output.append("\nDecrypted a file using XOR");
			} catch (IOException | NullPointerException e1) {
				output.append("\nError: Please encrypt a file using XOR first.");
				e1.printStackTrace();
			}
		}
		else if(command.equals("Negation")) {
			try {
				negate();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		else if(command.equals("NEGdec")) {
			try {
				negdec();
				output.append("\nDecrypted a file using Negation");
			} catch (IOException | NullPointerException e1) {
				output.append("\nError: Please encrypt a file using negation first.");
				e1.printStackTrace();
			}
		}
		else if(command.equals("AES")) {
			try {
				aes();
			} catch (InvalidKeyException | NoSuchPaddingException | NoSuchAlgorithmException | BadPaddingException
					| IllegalBlockSizeException | IOException e1) {
				e1.printStackTrace();
			}
		}
		else if(command.equals("AESdec")) {
			try {
				aesdec();
				output.append("\nDecrypted a file using AES");
			} catch (InvalidKeyException | NoSuchPaddingException | NoSuchAlgorithmException | BadPaddingException
					| IllegalBlockSizeException | IOException e1) {
				output.append("\nError: Please encrypt a file using AES first.");
				e1.printStackTrace();
			}
		}
		else if(command.equals("RSA")) {
			try {
				rsa();
			} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException 
					| BadPaddingException | InvalidKeySpecException | IOException e1) {
				e1.printStackTrace();
			} catch (IllegalBlockSizeException e1) {
				output.append("\nSorry, that file is too large to encrypt using RSA");
				e1.printStackTrace();
			}
		}
		else if(command.equals("RSAdec")) {
			try {
				rsadec();
				output.append("\nDecrypted a file using RSA");
			} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException
					| BadPaddingException | InvalidKeySpecException | IOException e1) {
				output.append("\nError: Please encrypt a file using RSA first.");
				e1.printStackTrace();
			}
		}
		else if(command.equals("Exit")) {
			output.setText("\nGoodbye");
			System.exit(0);
		}
		
}

public static void xor() throws IOException, NoSuchAlgorithmException {
		
		FileInputStream in = null;			//Our three ByteStreams
		FileOutputStream out = null;
		FileInputStream key = null;
		String fileName = null;
		try {
			fd.setDirectory("C:/");
			fd.setVisible(true);
			fd.requestFocus();
			File[] f = fd.getFiles();
			String filePath = fd.getFiles()[0].getAbsolutePath();
			fileName = f[0].getName();
	        File file = new File(filePath);
			in = new FileInputStream(file);		//This is where the input, output, and key are specified
			out = new FileOutputStream("C:/CS4800/xorenc.txt");
			KeyGenerator keyGen = KeyGenerator.getInstance("AES");    //create AES key (128 bit)
			keyGen.init(128);
			SecretKey secretKey = keyGen.generateKey();
			String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());        //encode secretKey to a string to write
			FileOutputStream writeKey = new FileOutputStream("C:/CS4800/key.txt");
			writeKey.write(encodedKey.getBytes());    //write encodedKey to a file called aeskey.txt
			writeKey.close();
			key = new FileInputStream("C:/CS4800/key.txt");
			int c;
			int k;
			while((c = in.read()) != -1) {
				k = key.read();
				if(k == -1) {
					key.close();
					key = new FileInputStream("C:/CS4800/key.txt");
					k = key.read();
				}
				c = c ^ k;						//Here is where the XOR actually happens
				out.write(c);
			}
		} finally {
			in.close();
			out.close();
			key.close();
			output.append("\nEncrypted " + fileName + " using XOR.");
		}
	}

	public static void xordec() throws IOException, NullPointerException {
		
		FileInputStream in = null;			//Our three ByteStreams
		FileOutputStream out = null;
		FileInputStream key = null;
		try {
			in = new FileInputStream("C:/CS4800/xorenc.txt");		//This is where the input, output, and key are specified
			out = new FileOutputStream("C:/CS4800/xordec.txt");
			key = new FileInputStream("C:/CS4800/key.txt");
			int c;
			int k;
			while((c = in.read()) != -1) {
				k = key.read();
				if(k == -1) {			//This part allows us to have keys of various sizes (it seems multiples of 32 bits)
					key.close();
					key = new FileInputStream("C:/CS4800/key.txt");
					k = key.read();
				}
				c = c ^ k;						//Here is where the XOR actually happens
				out.write(c);
			}
		} finally {
			in.close();
			out.close();
			key.close();
		}
	}
	
	public static void negate() throws IOException {
		
		FileInputStream in = null;			//Our two ByteStreams
		FileOutputStream out = null;
		String fileName = null;
		try {
			fd.setDirectory("C:/");
			fd.setVisible(true);
			fd.requestFocus();
			File[] f = fd.getFiles();
			String filePath = fd.getFiles()[0].getAbsolutePath();
			fileName = f[0].getName();
	        File file = new File(filePath);
			in = new FileInputStream(file);
			out = new FileOutputStream("C:/CS4800/negenc.txt");
			int c;
			while((c = in.read()) != -1) {
				c = ~c;						//This is our negation. It flips each bit so we don't need a key.
				out.write(c);
			}
		} finally {
			in.close();
			out.close();
			output.append("\nEncrypted " + fileName + " using negation.");
		}
	}
	
public static void negdec() throws IOException {
		
		FileInputStream in = null;			//Our two ByteStreams
		FileOutputStream out = null;
		try {
			in = new FileInputStream("C:/CS4800/negenc.txt");
			out = new FileOutputStream("C:/CS4800/negdec.txt");
			int c;
			while((c = in.read()) != -1) {
				c = ~c;						//This is our negation. It flips each bit so we don't need a key.
				out.write(c);
			}
		} finally {
			in.close();
			out.close();
		}
	}
	
	public static void aes() throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, IOException {
		
		// Standard AES key creation
		KeyGenerator keyGen = KeyGenerator.getInstance("AES");    //create AES key (128 bit)
		keyGen.init(128);
		SecretKey secretKey = keyGen.generateKey();
		String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());        //encode secretKey to a string to write
		FileOutputStream writeKey = new FileOutputStream("C:/CS4800/aeskey.txt");
		writeKey.write(encodedKey.getBytes());    //write encodedKey to a file called aeskey.txt
		writeKey.close();
		
		fd.setDirectory("C:/");
		fd.setVisible(true);
		fd.requestFocus();
		File[] f = fd.getFiles();
		String filePath = fd.getFiles()[0].getAbsolutePath();
		String fileName = f[0].getName();
		File file = new File(filePath);
        String readKey = new String(Files.readAllBytes(Paths.get("C:/CS4800/aeskey.txt")));    //reads in the string aeskey.txt
        byte[]decodedKey = Base64.getDecoder().decode(readKey);        //convert readKey(string) to a byte array
        SecretKey originalKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");        //use byte array to recreate a Secret Key object
        Cipher aesCipher = Cipher.getInstance("AES");    //encrypt using AES
        aesCipher.init(Cipher.ENCRYPT_MODE,  originalKey);
        FileInputStream readInputFile = new FileInputStream(file);        //file to encrypt (in eclipse project folder or specify a path)
        byte[] inputBytes = new byte[(int) file.length()];
        readInputFile.read(inputBytes);
        byte[] outputBytes = aesCipher.doFinal(inputBytes);
        String encodedEncrypted = Base64.getEncoder().encodeToString(outputBytes);
        FileOutputStream writeEncrypted = new FileOutputStream("C:/CS4800/aesenc.txt");
        writeEncrypted.write(encodedEncrypted.getBytes());    //write the output to a file called aesdec.txt
        writeEncrypted.close();
        readInputFile.close();
        output.append("\nEncrypted " + fileName + " using AES.");
		
	}
	public static void aesdec() throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, IOException {
		
		Cipher aesCipher = Cipher.getInstance("AES");
        String readKeyToDec = new String(Files.readAllBytes(Paths.get("C:/CS4800/aeskey.txt")));    //reads in the string aeskey.txt
        byte[]decodedKeyDec = Base64.getDecoder().decode(readKeyToDec);        //convert readKey(string) to a byte array
        SecretKey originalKeyDec = new SecretKeySpec(decodedKeyDec, 0, decodedKeyDec.length, "AES");        //use byte array to recreate a Secret Key object
        aesCipher.init(Cipher.DECRYPT_MODE,  originalKeyDec);    //decrypt using AES and the key we recreated
        String readEncrypted = new String(Files.readAllBytes(Paths.get("C:/CS4800/aesenc.txt")));
        byte[] decodedEncrypted = Base64.getDecoder().decode(readEncrypted);
        byte[] decrypted = aesCipher.doFinal(decodedEncrypted);
        FileOutputStream writeDecrypted = new FileOutputStream("C:/CS4800/aesdec.txt");
        writeDecrypted.write(decrypted);    //write the output to a file called aesdec.txt
        writeDecrypted.close();
        
	}
	
	public static void rsa() throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException {
        
		KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");    //create RSA key pair (1024 bit private key)
        keyGen.initialize(2048);
        KeyPair pair = keyGen.generateKeyPair();
        PrivateKey privateKey = pair.getPrivate();
        PublicKey publicKey = pair.getPublic();
        String encodedPrivateKey = Base64.getEncoder().encodeToString(privateKey.getEncoded());    //encode privateKey to a string to write
        String encodedPublicKey = Base64.getEncoder().encodeToString(publicKey.getEncoded());
        FileOutputStream writePrivateKey = new FileOutputStream("C:/CS4800/rsaprivatekey.txt");
        writePrivateKey.write(encodedPrivateKey.getBytes());        //write encodedKey to a file called rsakey.txt
        FileOutputStream writePublicKey = new FileOutputStream("C:/CS4800/rsapublickey.txt");
        writePublicKey.write(encodedPublicKey.getBytes());
        writePrivateKey.close();
        writePublicKey.close();
        
		fd.setDirectory("C:/");
		fd.setVisible(true);
		fd.requestFocus();
		File[] f = fd.getFiles();
		String filePath = fd.getFiles()[0].getAbsolutePath();
		String fileName = f[0].getName();
        File file = new File(filePath);
        String readKey = new String(Files.readAllBytes(Paths.get("C:/CS4800/rsapublickey.txt")));    //reads in the string rsakey.txt
        byte[] decodedKey = Base64.getDecoder().decode(readKey);        //convert readKey(string) to a byte array
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(decodedKey);        //create a key spec and key factory to recreate a private key object
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey originalKey = keyFactory.generatePublic(keySpec);
        Cipher rsaCipher = Cipher.getInstance("RSA");    //encrypt using RSA
        rsaCipher.init(Cipher.ENCRYPT_MODE, originalKey);
        FileInputStream readInputFile = new FileInputStream(file);        //file to encrypt
        byte[] inputBytes = new byte[(int) file.length()];
        readInputFile.read(inputBytes);
        byte[] outputBytes = rsaCipher.doFinal(inputBytes);
        String encodedEncrypted = Base64.getEncoder().encodeToString(outputBytes);
        FileOutputStream writeEncrypted = new FileOutputStream("C:/CS4800/rsaenc.txt");
        writeEncrypted.write(encodedEncrypted.getBytes());    //write the output to a file called aesdec.txt
        writeEncrypted.close();
        readInputFile.close();
        output.append("\nEncrypted " + fileName + " using RSA.");
        
	}
	
	public static void rsadec() throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException {
        
        String readKeyToDec = new String(Files.readAllBytes(Paths.get("C:/CS4800/rsaprivatekey.txt")));    //reads in the string rsakey.txt
        byte[]decodedKeyDec = Base64.getDecoder().decode(readKeyToDec);        //convert readKey(string) to a byte array
        PKCS8EncodedKeySpec keySpecDec = new PKCS8EncodedKeySpec(decodedKeyDec);        //create a key spec and key factory to recreate a private key object
        KeyFactory keyFactoryDec = KeyFactory.getInstance("RSA");
        PrivateKey originalKeyDec = keyFactoryDec.generatePrivate(keySpecDec);
        Cipher rsaCipher = Cipher.getInstance("RSA");
        rsaCipher.init(Cipher.DECRYPT_MODE, originalKeyDec);    //decrypt using RSA and the key we recreated
        String readEncrypted = new String(Files.readAllBytes(Paths.get("C:/CS4800/rsaenc.txt")));
        byte[] decodedEncrypted = Base64.getDecoder().decode(readEncrypted);
        byte[] decrypted = rsaCipher.doFinal(decodedEncrypted);
        FileOutputStream writeDecrypted = new FileOutputStream("C:/CS4800/rsadec.txt");
        writeDecrypted.write(decrypted);    //write the output to a file called rsadec.txt
        writeDecrypted.close();
        
	}
}
